"use strict";
/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunksm_ocl_payments"] = self["webpackChunksm_ocl_payments"] || []).push([["modal"],{

/***/ "./sm-ocl-payments/src/js/modal.js":
/*!*****************************************!*\
  !*** ./sm-ocl-payments/src/js/modal.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   initModal: () => (/* binding */ initModal),\n/* harmony export */   toggleModal: () => (/* binding */ toggleModal)\n/* harmony export */ });\n/* harmony import */ var lodash_forEach__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash/forEach */ \"./node_modules/lodash/forEach.js\");\n/* harmony import */ var lodash_forEach__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash_forEach__WEBPACK_IMPORTED_MODULE_0__);\n\nvar initModal = function initModal(modal) {\n  var closeModal = modal.querySelectorAll('[data-ocl-modal-close]');\n  lodash_forEach__WEBPACK_IMPORTED_MODULE_0___default()(closeModal, function (close) {\n    close.addEventListener(\"click\", function (e) {\n      e.preventDefault();\n      modal.classList.remove('is-open');\n    });\n  });\n};\nvar toggleModal = function toggleModal(button) {\n  var modal = document.querySelector(button.getAttribute(\"href\"));\n  if (modal) {\n    button.addEventListener(\"click\", function (event) {\n      event.preventDefault();\n      modal.classList.add('is-open');\n    });\n  }\n};\n\n//# sourceURL=webpack://sm-ocl-payments/./sm-ocl-payments/src/js/modal.js?");

/***/ })

}]);