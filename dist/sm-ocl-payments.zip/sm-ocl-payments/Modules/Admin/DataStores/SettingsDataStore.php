<?php

namespace SM\OclPayments\Modules\Admin\DataStores;

use SM\Core\Admin\Forms\DataStore;

class SettingsDataStore extends DataStore {
  public const DATA_KEY = 'sm_ocl_payments_settings';
  public const GLOBAL = true;
}